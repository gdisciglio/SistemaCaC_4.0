package ar.org.cac.fullstack.interfaces;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCaC_Application {

	public static void main(String[] args) {
		SpringApplication.run(SistemaCaC_Application.class, args);
	}

}

package ar.org.cac.fullstack.interfaces.enums;

public enum Turno {
	MAÑANA,
	TARDE,
	NOCHE
}

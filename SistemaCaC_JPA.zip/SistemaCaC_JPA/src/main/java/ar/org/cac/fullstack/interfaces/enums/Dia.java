package ar.org.cac.fullstack.interfaces.enums;

public enum Dia {
	LUNES,
	MARTES,
	MIERCOLES,
	JUEVES,
	VIERNES
}

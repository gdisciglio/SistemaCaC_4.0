-- Registros de prueba
use CodoaCodo;

INSERT INTO cursos (titulo, profesor, dia, turno) VALUES
    ('Full Stack Java', 'Mabel Escobar', 'LUNES', 'MAÑANA'),
    ('Full Stack PHP', 'Profesor B', 'MARTES', 'TARDE'),
    ('Full Stack Python', 'Profesor C', 'MIERCOLES', 'MAÑANA'),
    ('Full Stack Desarrollo Web', 'Profesor D', 'JUEVES', 'TARDE');
    
INSERT INTO alumnos (nombre, apellido, edad, id_curso) VALUES
    ('Juan', 'Pérez', 20, 1),
    ('María', 'González', 22, 2),
    ('Carlos', 'López', 19, 3),
    ('Laura', 'Rodríguez', 21, 4);